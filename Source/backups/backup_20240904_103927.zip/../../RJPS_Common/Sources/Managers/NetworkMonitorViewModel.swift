//
//  NetworkMonitorViewModel.swift
//  Common
//
//  Created by Ricardo Santos on 05/08/2024.
//

public extension Common {
    typealias NetworkMonitorViewModel = CommonNetworking.NetworkMonitorViewModel
}
